cargo build --release
(cd wasm; bash build.sh)
