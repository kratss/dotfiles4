rm -rf pkg
cp -r ../pkg .
python -m http.server
