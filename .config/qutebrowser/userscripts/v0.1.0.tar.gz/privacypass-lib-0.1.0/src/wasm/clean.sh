rm -rf pkg
rm -rf example/pkg
