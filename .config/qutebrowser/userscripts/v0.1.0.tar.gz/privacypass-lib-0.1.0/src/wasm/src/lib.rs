#[macro_use]
extern crate panic_handler;

mod client;