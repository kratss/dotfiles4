cargo clean
rm Cargo.lock
(cd wasm; bash clean.sh)
