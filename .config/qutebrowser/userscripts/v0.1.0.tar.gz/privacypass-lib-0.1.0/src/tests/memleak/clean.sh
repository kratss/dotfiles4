rm -rf bin/
