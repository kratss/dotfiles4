LD_LIBRARY_PATH=../target/release valgrind ./bin/main
